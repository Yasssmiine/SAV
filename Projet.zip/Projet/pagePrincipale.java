import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.sql.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.ArrayList;


public class pagePrincipale extends JFrame {
    static JButton btn;
    static JButton btn2;
    static JButton btn3;
    static JButton btn4;
    static JButton btn5;
    static int ID;
    static String Nom;
    static String Prenom;
    static String Telephone;
    static String Declaration;
    static String Date;
    static String Ticket;
    static String Etat;
    static String Probleme;
    static DefaultTableModel newmodel = new DefaultTableModel();
    static JTable table = new JTable(newmodel);
    static JTextField a;
    static JTextField b;
    static JTextField c;
    static JComboBox<String> cb;
    static JTextField dateField;
    static JTextField ticket2;
    static JComboBox<String> et;
    static JComboBox<String> p;

    public pagePrincipale() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 500);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel text1 = new JLabel("Nom");
        text1.setBounds(30, 40, 200, 30);
        add(text1);
        a = new JTextField("");
        a.setBounds(150, 40, 200, 25);
        add(a);

        JLabel text2 = new JLabel("Prénom");
        text2.setBounds(30, 80, 200, 30);
        add(text2);
        b = new JTextField("");
        b.setBounds(150, 80, 200, 25);
        add(b);

        JLabel text3 = new JLabel("Téléphone");
        text3.setBounds(30, 120, 200, 30);
        add(text3);
        c = new JTextField("");
        c.setBounds(150, 120, 200, 25);
        add(c);

        JLabel deroulant = new JLabel("Déclaration : ");
        deroulant.setBounds(30, 160, 200, 25);
        add(deroulant);
        String[] choices = {"CHOICE 1", "CHOICE 2", "CHOICE 3", "CHOICE 4", "CHOICE 5", "CHOICE 6"};
        cb = new JComboBox<>(choices);
        cb.setBounds(150, 160, 200, 25);
        add(cb);

        JLabel date = new JLabel("Date du jour :");
        date.setBounds(30, 200, 200, 30);
        add(date);
        dateField = new JTextField(10);
        dateField.setBounds(150, 200, 200, 25);
        add(dateField);
        LocalDate dateDuJour = LocalDate.now();
        dateField.setText(dateDuJour.toString());

        JLabel ticket = new JLabel("Numéro de ticket :");
        ticket.setBounds(30, 240, 200, 25);
        add(ticket);
        ticket2 = new JTextField(10);
        ticket2.setBounds(150, 240, 200, 25);
        add(ticket2);

        JLabel etat = new JLabel("Etat du ticket :");
        etat.setBounds(30, 280, 200, 25);
        add(etat);
        String[] choix = {"Ouvert", "En cours", "Fermer"};
        et = new JComboBox<>(choix);
        et.setBounds(150, 280, 200, 25);
        add(et);

        JLabel problem = new JLabel("Type de problème : ");
        problem.setBounds(30, 320, 200, 25);
        add(problem);
        String[] pro = {"Ne fonctionne plus", "Ne s'allume pas", "Probleme"};
        p = new JComboBox<>(pro);
        p.setBounds(150, 320, 200, 25);
        add(p);

        table.setBounds(30, 400, 500, 100);
        newmodel.addColumn("ID");
        newmodel.addColumn("Nom");
        newmodel.addColumn("Prénom");
        newmodel.addColumn("Téléphone");
        newmodel.addColumn("Declaration");
        newmodel.addColumn("Date");
        newmodel.addColumn("Numéro de ticket"); 
        newmodel.addColumn("Etat du ticket");
        newmodel.addColumn("Type de problème");
        add(new JScrollPane(table));



        btn = new JButton("ajouter");
        btn.setBounds(30, 360, 100, 25);
        btn.setForeground(Color.BLACK);
        btn.setBackground(Color.WHITE);
        add(btn);

        btn2 = new JButton("supprimer");
        btn2.setBounds(150, 360, 120, 25);
        btn2.setBackground(Color.lightGray);
        add(btn2);

        btn3 = new JButton("modifier");
        btn3.setBounds(280, 360, 120, 25);
        btn3.setBackground(Color.PINK);
        add(btn3);

        btn4 = new JButton("comptage");
        btn4.setBounds(410, 360, 140, 25);
        btn4.setBackground(Color.yellow);
        add(btn4);

        btn5 = new JButton("reclamation");
        btn5.setBounds(560, 360, 120, 25);
        add(btn5);

        setVisible(true);
        

        // Ajout des actions pour les boutons
        btn.addActionListener(e -> ajouter());
        btn2.addActionListener(e -> delete());
        btn3.addActionListener(e -> modifier());
        btn4.addActionListener(e -> comptage());
        btn5.addActionListener(e -> reclamation());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(pagePrincipale::new);

        
        {

            String url = "jdbc:mysql://localhost:3306/formulaire";
            String username = "root";
            String password= "";

            try      
            {

            Class.forName("com.mysql.cj.jdbc.Driver");         
            Connection conn = DriverManager.getConnection(url, username, password);      
            Statement stmt = conn.createStatement();        
            ResultSet res = stmt.executeQuery("SELECT * FROM client");

            

            while(res.next()) {

                ID = res.getInt(1);        
                Nom = res.getString(2);       
                Prenom = res.getString(3);       
                Telephone = res.getString(4);        
                Declaration = res.getString(5);        
                Date = res.getString(6);      
                Ticket = res.getString(7);       
                Etat = res.getString(8);
                Probleme = res.getString(9);


                System.out.println("kljjk"+ Ticket);

                newmodel.addRow(new Object[]{ID, Nom, Prenom, Telephone, Declaration, Date, Ticket, Etat, Probleme});
           }

              conn.close();      
            }
            catch (Exception e1) {
                System.out.println(e1);        
            }

            

            };


        
    }

  
    private static void ajouter() {
        btn = new JButton("ajouter");
        btn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == btn) {
                    {
                        String url = "jdbc:mysql://localhost:3306/formulaire";
                        String username = "root";
                        String password = "";

                        String PrenomField = a.getText();
                        String NomField = b.getText();
                        String TelField = c.getText();
                        String DeclaField = cb.getSelectedItem().toString();
                        String DayField = dateField.getText();
                        String TicketField = ticket2.getText();
                        String EtatField = et.getSelectedItem().toString();
                        String ProblemField = p.getSelectedItem().toString();

                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver");
                        } catch (ClassNotFoundException e1) {
                            e1.printStackTrace();
                        }

                        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/formulaire", "root", "")) {
                            String insertQuery = "INSERT INTO `client` (`ID`, `Prenom`, `Nom`, `Telephone`, `Declaration`, `Date`, `Ticket`, `Etat`, `Probleme`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);";
                            try (PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {
                                pstmt.setString(1, null);
                                pstmt.setString(2, PrenomField);
                                pstmt.setString(3, NomField);
                                pstmt.setString(4, TelField);
                                pstmt.setString(5, DeclaField);
                                pstmt.setString(6, DayField);
                                pstmt.setString(7, TicketField);
                                pstmt.setString(8, EtatField);
                                pstmt.setString(9, ProblemField);

                                pstmt.executeUpdate();
                                System.out.println(DeclaField);

                            }
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                            System.out.println("Erreur lors de l'ajout des données dans la base de données.");
                        }
                    }
                }
            }
        });


        

        Border line = new LineBorder(Color.BLACK);
        Border margin = new EmptyBorder(5, 15, 5, 15);
        Border compound = new CompoundBorder(line, margin);
        btn.setBorder(compound);

        
        
    }

    private static void delete() {

        
                
        btn2 = new JButton("supprimer");
        btn2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (e.getSource()==btn2){
                    {
                        String url = "jdbc:mysql://localhost:3306/formulaire";
                        String username = "root";
                        String password= "";

                        int idRow = table.getSelectedRow();
                        int idUser = (int) table.getValueAt(idRow, 0);

                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver"); 
                            Connection conn= DriverManager.getConnection(url, username, password);
                            PreparedStatement st = conn.prepareStatement("DELETE FROM `client` WHERE `ID` = " + idUser);
                            st.executeUpdate();
                            }
                        
                        catch (Exception e1) {
                            System.out.println(e1);
                            }                    
                            }
                        }
                    }
                  });

        btn2.setBounds(150, 360, 120, 25);
        btn2.setVisible(true);
        btn2.setBackground(Color.lightGray);
        

    }
 
    private static void modifier(){
        btn3 = new JButton("modifier");
        btn3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (e.getSource()==btn3){
                    {
                        String url = "jdbc:mysql://localhost:3306/formulaire";
                        String username = "root";
                        String password= "";


                        int idRow = table.getSelectedRow();
                        int idUser = (int) table.getValueAt(idRow, 0);
                        String idNom = (String) table.getValueAt(idRow, 1);
                        String idPre = (String) table.getValueAt(idRow, 2);
                        String idTel = (String) table.getValueAt(idRow, 3);
                        String idDe = (String) table.getValueAt(idRow, 4);
                        String idDate = (String) table.getValueAt(idRow, 5);
                        String idTick = (String) table.getValueAt(idRow, 6);
                        String idEtat = (String) table.getValueAt(idRow, 7);
                        String idPro = (String) table.getValueAt(idRow,8);


                        try {
                            Class.forName("com.mysql.cj.jdbc.Driver"); 
                            Connection conn= DriverManager.getConnection(url, username, password);
                            PreparedStatement st = conn.prepareStatement("UPDATE `client` SET `Nom` = '"+ idNom+"', `Prenom` = '"+ idPre+"', `Telephone` = '"+ idTel+"', `Declaration` = '"+ idDe+"', `Date` = '"+ idDate +"', `Ticket` = '"+ idTick+"', `Etat` = '"+ idEtat+"', `Probleme` = '"+ idPro +"'  WHERE ID = " + idUser);
                            
                                                         
                            
        
                            st.executeUpdate();
                            System.out.println(idNom);
                            System.out.println(idPre);
                        }
                        catch (Exception e1){
                            System.out.println(e1);
                        }
                    }
                }
            }
        });


        btn3.setBounds(280, 360, 120, 25);
        btn3.setVisible(true);
        btn3.setBackground(Color.PINK);
        
    }

    private static void comptage() {
        btn4 = new JButton("comptage");
        btn4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame secondeFenetre = new JFrame();
                secondeFenetre.setBounds(0, 0, 300, 300);
                secondeFenetre.setLayout(null); // Utilisation d'un layout null pour positionner les éléments manuellement
                secondeFenetre.setVisible(true);
    
                JLabel label = new JLabel();
                label.setBounds(100, 100, 200, 30); // Positionnement du label dans la fenêtre
    
                secondeFenetre.add(label); // Ajout du label à la fenêtre
    
                try {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/formulaire", "root", "");
                    Statement stmt = conn.createStatement();
                    ResultSet res = stmt.executeQuery("SELECT COUNT(*) AS count FROM client WHERE Etat = 'En cours'");
    
                    // Récupération du résultat
                    int count = 0;
                    while (res.next()) {
                        count = res.getInt("count");
                    }
    
                    conn.close();
    
                    // Affichage du résultat dans le label
                    label.setText("Ticket en cours : " + count);
                } catch (Exception ex) {
                    System.out.println(ex);
                }
            }
        });
    
        btn4.setBounds(410, 360, 140, 25);
        btn4.setVisible(true);
        btn4.setBackground(Color.yellow);
    }
    
    private static void reclamation() {
        btn5 = new JButton("reclamation");
        btn5.setBounds(560,360,120,25);
        btn5.setVisible(true);

        

        btn5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame deuxiemeFenetre = new JFrame();
                deuxiemeFenetre.setBounds(0,0,500,500);
                deuxiemeFenetre.setLayout(null);
                deuxiemeFenetre.setVisible(true);
                
                JLabel titreLabel = new JLabel("Insérer votre réclamation ");
                titreLabel.setBounds(110, 40, 200, 30);

                JLabel reclamationLabel = new JLabel("Réclamation :");
                reclamationLabel.setBounds(30, 80, 200, 30);
                JTextField reclaField = new JTextField("");
                reclaField.setBounds(160,80,200,25);

                JButton ajouterButton = new JButton("Ajouter");
                ajouterButton.setBounds(200, 200, 100, 25);

                deuxiemeFenetre.add(titreLabel);
                deuxiemeFenetre.add(reclaField);
                deuxiemeFenetre.add(reclamationLabel);
                deuxiemeFenetre.add(ajouterButton);

                ajouterButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        String reclamationText = reclaField.getText();

        // Vérification que le texte de la réclamation n'est pas vide
        if (!reclamationText.isEmpty()) {
            // Connexion à la base de données
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/formulaire", "root", "")) {
                // Requête SQL pour insérer la réclamation dans la table client
                String insertQuery = "INSERT INTO client (Reclamation) VALUES (?);";
                
                try (PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {
                    pstmt.setString(1, reclamationText);
                    // Exécution de la requête
                    pstmt.executeUpdate();
                    
                    // Affichage d'un message de confirmation
                    JOptionPane.showMessageDialog(null, "Réclamation ajoutée avec succès !");
                    
                    // Effacer le champ de réclamation après l'ajout
                    reclaField.setText("");
                }
            } catch (SQLException ex) {
                // En cas d'erreur lors de la connexion à la base de données ou de l'exécution de la requête
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Erreur lors de l'ajout de la réclamation : " + ex.getMessage());
            }
        } else {
            // Si le champ de réclamation est vide, afficher un message d'erreur
            JOptionPane.showMessageDialog(null, "Veuillez saisir une réclamation avant d'ajouter !");
        }
    }
});
        
            }
        });

    }

}

//System.out.println("Fonction reclamation() non implémentée");

