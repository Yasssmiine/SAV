import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class connexion extends JFrame implements ActionListener {
    private JTextField txtLogin;
    private JPasswordField txtMotDePasse;
    private JButton btnConnexion;

    public connexion() {
        setTitle("Page de Connexion");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(3, 2));

        JLabel lblLogin = new JLabel("Login:");
        add(lblLogin);

        txtLogin = new JTextField();
        add(txtLogin);

        JLabel lblMotDePasse = new JLabel("Mot de passe:");
        add(lblMotDePasse);

        txtMotDePasse = new JPasswordField();
        add(txtMotDePasse);

        btnConnexion = new JButton("Connexion");
        btnConnexion.addActionListener(this);
        add(btnConnexion);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnConnexion) {
            String login = txtLogin.getText();
            String motDePasse = new String(txtMotDePasse.getPassword());

            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/formulaire", "root", "")) {
                String selectQuery = "SELECT statut FROM connexion WHERE login = ? AND password = ?";
                try (PreparedStatement pstmt = conn.prepareStatement(selectQuery)) {
                    pstmt.setString(1, login);
                    pstmt.setString(2, motDePasse);
                    ResultSet rs = pstmt.executeQuery();
                    if (rs.next()) {
                        String statut = rs.getString("statut");
                        if (statut.equals("employe")) {
                            dispose();
                            // Redirection vers projetest3.java
                            projetest3 projet1 = new projetest3();
                            projet1.setVisible(true);
                        } else if (statut.equals("client")) {
                            dispose();
                            // Redirection vers projetest2.java
                            projetest2 projet2 = new projetest2();
                            projet2.setVisible(true);
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Identifiants incorrects !", "Erreur", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Erreur lors de la connexion à la base de données.", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new connexion();
            }
        });
    }
}
