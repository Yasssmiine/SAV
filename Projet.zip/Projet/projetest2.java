import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class projetest2 extends JFrame {
    private JButton btnAbsence;
    private JButton btnDemande;
    private JButton btnEtatDemande;

    public projetest2() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 500); // Taille agrandie
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 1)); // Ajustement pour inclure le titre

        // Ajout du titre à la fenêtre
        JLabel titleLabel = new JLabel("Gestion des Employés");
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(titleLabel);

        // Création des boutons
        btnAbsence = new JButton("Justifier Absence");
        btnDemande = new JButton("Faire une Demande");
        btnEtatDemande = new JButton("Voir l'État des Demandes");

        // Ajout des listeners aux boutons
        btnAbsence.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                afficherFormulaireAbsence(); // Nouvelle méthode pour afficher le formulaire d'absence
            }
        });

        btnDemande.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                faireDemande();
            }
        });

        btnEtatDemande.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                etatDemande();
            }
        });

        // Ajout des boutons à la fenêtre
        add(btnAbsence);
        add(btnDemande);
        add(btnEtatDemande);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new projetest2());
    }

    // Nouvelle méthode pour afficher le formulaire d'absence
    private void afficherFormulaireAbsence() {
        // Création de la nouvelle fenêtre pour le formulaire d'absence
        JFrame formulaireFrame = new JFrame("Formulaire d'Absence");
        formulaireFrame.setSize(400, 300);
        formulaireFrame.setLayout(new GridLayout(5, 2)); // Ajustement pour les champs du formulaire
        formulaireFrame.setLocationRelativeTo(null);

        // Ajout des composants pour le formulaire
        JLabel lblNom = new JLabel("Nom:");
        JTextField txtNom = new JTextField();
        JLabel lblPrenom = new JLabel("Prénom:");
        JTextField txtPrenom = new JTextField();
        JLabel lblDateAbsence = new JLabel("Date d'Absence:");
        JTextField txtDateAbsence = new JTextField();
        JLabel lblDureeAbsence = new JLabel("Durée d'Absence:");
        JTextField txtDureeAbsence = new JTextField();

        JButton btnValider = new JButton("Valider");

        // Ajout d'un écouteur pour le bouton de validation
        btnValider.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Récupération des données saisies dans le formulaire
                String nom = txtNom.getText();
                String prenom = txtPrenom.getText();
                String dateAbsence = txtDateAbsence.getText();
                String dureeAbsence = txtDureeAbsence.getText();

                // Enregistrement des données dans la base de données
                try {
                    Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/formulaire", "root", "");
                    PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO absence (nom, prenom, date_abscence, duree_abscence) VALUES (?, ?, ?, ?)");
                    preparedStatement.setString(1, nom);
                    preparedStatement.setString(2, prenom);
                    preparedStatement.setString(3, dateAbsence);
                    preparedStatement.setString(4, dureeAbsence);
                    preparedStatement.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Absence justifiée avec succès!");
                    connection.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        // Ajout des composants à la fenêtre
        formulaireFrame.add(lblNom);
        formulaireFrame.add(txtNom);
        formulaireFrame.add(lblPrenom);
        formulaireFrame.add(txtPrenom);
        formulaireFrame.add(lblDateAbsence);
        formulaireFrame.add(txtDateAbsence);
        formulaireFrame.add(lblDureeAbsence);
        formulaireFrame.add(txtDureeAbsence);
        formulaireFrame.add(btnValider);

        formulaireFrame.setVisible(true);
    }

    // Méthode pour faire une demande
    private void faireDemande() {
        // Implémenter la logique pour faire une demande
        JOptionPane.showMessageDialog(this, "Fonctionnalité non implémentée : Faire Demande");
    }

    // Méthode pour afficher l'état des demandes
    private void etatDemande() {
        // Implémenter la logique pour afficher l'état des demandes
        JOptionPane.showMessageDialog(this, "Fonctionnalité non implémentée : État des Demandes");
    }
}
